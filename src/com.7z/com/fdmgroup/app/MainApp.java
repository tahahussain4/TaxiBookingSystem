package com.fdmgroup.app;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;

import com.fdmgroup.controller.BookingController;
import com.fdmgroup.controller.CarManagementController;
import com.fdmgroup.controller.HomeController;
import com.fdmgroup.controller.RoleManagementController;
import com.fdmgroup.controller.UserManagementController;
import com.fdmgroup.model.Booking;
import com.fdmgroup.model.Car;
import com.fdmgroup.model.Role;
import com.fdmgroup.model.Size;
import com.fdmgroup.model.User;
import com.fdmgroup.view.HomeView;



public class MainApp {
	public static void main(String[] args) {
		
		RoleManagementController rmc = new RoleManagementController();
		UserManagementController umc = new UserManagementController();
//		CarManagementController cmc = new CarManagementController();
//		
////		Role role = new Role(4);
//		Role roleCust = new Role("customer");
		Role roleAdmin = new Role("admin");
//		
//		rmc.addRole("roleCust");
		rmc.addRole("admin");
//		
		umc.addUser("taha1", "hussain", "taha", "taha", roleAdmin, "taha", LocalDate.of(1994, 9, 03));
//		umc.addUser("taha", "taha", "taha", "taha", roleCust, "taha", LocalDate.of(1994, 9, 03));
		
		
		//cmc.addCar("2010",Size.SMALL,"autmatic", 4);
		//cmc.addCar("2010",Size.SMALL,"autmatic", 2);
		//cmc.addCar("2010",Size.small,"autmatic", 4);
		//HomeController hc = HomeController.getInstance();
		
		BookingController bc = new BookingController();
			
		bc.addNew(LocalDate.of(1994, 9, 03), LocalTime.of(12, 13), Size.MEDIUM, "dd", "tt",false);
		//hc.showHome();
	}
}
