package com.fdmgroup.controller;

import java.util.List;

import com.fdmgroup.dao.IRoleDao;
import com.fdmgroup.dao.RoleJPADao;
import com.fdmgroup.model.Role;
import com.fdmgroup.view.RoleManagementView;

public class RoleManagementController {
	IRoleDao roleDao = new RoleJPADao();
	
	public void addRole(String role){
		Role newRole = new Role(role);
		Role createdRole = roleDao.create(newRole);
		if(createdRole != null){
			System.out.println("role successfully created");
		}
		else{
			System.out.println("role not succesfully created");
		}
	}
	
	public void deleteRole(int roleId){
		Role role = new Role(roleId);
		if(roleDao.delete(role)){
			System.out.println("Role succesfully deleted");
		}else{
			System.out.println("Role not successfully deleted");
		}
	}
	
	public void displayAllRoles(){
		List<Role> roleList = roleDao.findAll();
		for(Role role : roleList){
			System.out.println(role.toString());
		}
	}
	
	public void displayRoleManagementPage(){
		RoleManagementView roleManagementView = new RoleManagementView();
		roleManagementView.displayOptions();
	}
}
