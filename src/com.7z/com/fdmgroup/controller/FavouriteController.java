package com.fdmgroup.controller;



import java.util.List;

import com.fdmgroup.model.Favourite;
import com.fdmgroup.view.FavouriteView;

public class FavouriteController {
	
	public void displayFavouritePage(){
		FavouriteView favouriteView = new FavouriteView();
		favouriteView.displayOption();
	}
	
	public void addFavourite(int bookingId){
		
	}
	
	public void deleteFavourite(int bookingId){
		
	}
	
	public List<Favourite> getAllUserFavourites(){
		return null;
	}
}
