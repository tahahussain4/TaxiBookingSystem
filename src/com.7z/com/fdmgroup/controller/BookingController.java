package com.fdmgroup.controller;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.ArrayList;

import com.fdmgroup.dao.IBookingDao;
import com.fdmgroup.dao.BookingJPADao;
import com.fdmgroup.dao.IBookingDao;
import com.fdmgroup.model.Booking;
import com.fdmgroup.model.Car;
import com.fdmgroup.model.SessionUser;
import com.fdmgroup.model.Size;
import com.fdmgroup.view.BookingView;

public class BookingController {
    IBookingDao bookingDao = new BookingJPADao();
    
	public void showBookingPage(){
		BookingView bookingView = new BookingView();
		bookingView.displayBookingOptions();
	}
	
	public void deleteBooking(int bookingId){
		
		if(bookingDao.delete(new Booking(bookingId)) && bookingDao.findById(bookingId).getUser().getId() == SessionUser.getLoggedInUser().getId() ){
			System.out.println("booking deleted succesfully");
		}
		else{
			System.out.println("booking not deleted successfully");
		}
	}

	public void addNew(LocalDate localDate, LocalTime localTime, Size size, String pickUpLocation, String destination,
			boolean carPoolDecision) {
		Car availableCar = availableCar();
		Booking newBooking = new Booking(SessionUser.getLoggedInUser(),availableCar,LocalDateTime.of(localDate,localTime),pickUpLocation,destination,carPoolDecision);
		Booking createdBooking = bookingDao.create(newBooking);
		if(createdBooking != null){
			System.out.println("booking successfully created");
		}
		else{
			System.out.println("booking not succesfully created");
		}
		
	}

	public void changeBooking(int bookingId, LocalDate localDate, LocalTime localTime, Size size, String pickUpLocation,
			String destination, boolean carPoolDecision) {
		//car avaibleCar = fin car
		if(availableCar() != null && bookingDao.findById(bookingId).getUser().getId() == SessionUser.getLoggedInUser().getId()){
			Booking booking = new Booking(bookingId,null,null,LocalDateTime.of(localDate,localTime),pickUpLocation,destination,carPoolDecision);
			bookingDao.update(booking);
			System.out.println("booking success");
		}
		else{
			System.out.println("booking failed, Please retry");
		}
	}
	
	public Car availableCar(){
		return new Car();
	}
}
