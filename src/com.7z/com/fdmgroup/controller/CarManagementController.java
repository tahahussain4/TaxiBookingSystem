package com.fdmgroup.controller;

import com.fdmgroup.dao.CarJPADao;
import com.fdmgroup.dao.ICarDao;
import com.fdmgroup.model.Car;
import com.fdmgroup.model.Size;

public class CarManagementController {
	ICarDao carDao = new CarJPADao();
	public void addCar(String model, Size size, String gearType, int peopleCapacity){
		Car newCar = new Car(model,size,gearType,peopleCapacity);
		Car createdCar = carDao.create(newCar);
		if(createdCar != null){
			System.out.println("car successfully created");
		}
		else{
			System.out.println("car not succesfully created");
		}
	}
	
	public void deleteCar(int id){
		
		if(carDao.delete(new Car(id))){
			System.out.println("car deleted succesfully");
		}
		else{
			System.out.println("Car not deleted successfully");
		}
	}
	
}
