package com.fdmgroup.controller;

import java.time.LocalDate;

import com.fdmgroup.dao.IRoleDao;
import com.fdmgroup.dao.IUserDao;
import com.fdmgroup.dao.RoleJPADao;
import com.fdmgroup.dao.UserJPADao;
import com.fdmgroup.model.Car;
import com.fdmgroup.model.Role;
import com.fdmgroup.model.User;
import com.fdmgroup.view.UserManagementView;

public class UserManagementController {
	IUserDao userDao = new UserJPADao();
	IRoleDao roleDao = new RoleJPADao();
	
	public void addUser(String username,String password, String firstName, String lastName, Role role, String preferredLocation,LocalDate DOB){
		//Getting existing role
		Role foundRole = roleDao.findByRoleType(role.getRoleType());
		if(foundRole == null){
			System.out.println("role does not exist");
		}
		else{
			User newUser = new User(username, password, firstName, lastName,foundRole,preferredLocation,DOB);
			userDao.create(newUser);
		}
	}
	
	public void deleteUser(int userId){
		if(userDao.delete(new User(userId))){
			System.out.println("user deleted succesfully");
		}
		else{
			System.out.println("User not deleted successfully");
		}
	}
	
	public void deleteUser(String username){
		User foundUser = userDao.findByUsername(username);
		if(userDao.delete(foundUser)){
			System.out.println("user deleted succesfully");
		}
		else{
			System.out.println("User not deleted successfully");
		}
	}
	
	public void updateUser(String username,String password, String firstName, String lastName, String preferredLocation,LocalDate DOB){
		User updatedUser = userDao.update(new User(username,password,firstName,lastName,null,preferredLocation,DOB));
		if(updatedUser != null){
			System.out.println("successfully updating user");
		}else{
			System.out.println("failed updating user");
		}
	}
	
	public void displayOptions(){
		UserManagementView userManagementView = new UserManagementView();
		userManagementView.displayOptions();
	}
	
	public boolean doesUserExist(int id){
		if(userDao.findById(id) == null){
			return false;
		} else{
			return true;
		}
	}
}
