package com.fdmgroup.dao;

public interface IFavouriteDao extends IStorage {
	public void findUserFavourites();
}
