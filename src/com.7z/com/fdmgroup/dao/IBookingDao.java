package com.fdmgroup.dao;

import java.util.List;

import com.fdmgroup.model.Booking;

public interface IBookingDao extends IStorage<Booking> {
	public List<Booking> findAfterCurrentDate();
	public List<Booking> findAllUserBooking(int userId);
}
