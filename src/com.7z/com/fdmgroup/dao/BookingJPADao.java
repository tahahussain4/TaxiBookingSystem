package com.fdmgroup.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import com.fdmgroup.model.Booking;
import com.fdmgroup.model.User;

public class BookingJPADao implements IBookingDao{
	DbConnection connection;
	
	@Override
	public Booking findById(int id) {
		EntityManager em = connection.getInstance().getEntityManager();
		Booking foundBooking = em.find(Booking.class,id); 
		return foundBooking;
	}

	@Override
	public List<Booking> findAll() {
		EntityManager em = connection.getInstance().getEntityManager();		
		TypedQuery<Booking> query = em.createNamedQuery("booking.FindAll",Booking.class);
		List<Booking> bookingList = query.getResultList();
		
		return bookingList;
	}

	@Override
	public Booking create(Booking booking) {
 		EntityManager em = connection.getInstance().getEntityManager();
 		em.getTransaction().begin();
 		em.persist(booking);
 		em.getTransaction().commit();
		return booking;
	}

	@Override
	public Booking update(Booking booking) {
		EntityManager em = connection.getInstance().getEntityManager();
		Booking foundBooking = findById(booking.getBookingId());
		
		if (foundBooking == null){
			return null;
		}
		
		em.getTransaction().begin();
		
		if(booking.getCar() != null){
			foundBooking.setCar(booking.getCar());
		}
		if(booking.getDateTime() != null){
			foundBooking.setDateTime(booking.getDateTime());
		}
		if(booking.getPickUpLocation() != null){
			foundBooking.setPickUpLocation(booking.getPickUpLocation());
		}
		if(booking.getDestination() != null){
			foundBooking.setDestination(booking.getDestination());
		}
		if(booking.isCarPool() != null){
			foundBooking.setCarPool(booking.isCarPool());
		}
		
		return foundBooking;
	}

	@Override
	public boolean delete(Booking booking) {
		EntityManager em = connection.getInstance().getEntityManager();
		Booking foundBooking = findById(booking.getBookingId());
		
		if (foundBooking == null){
			return false;
		}
		
		em.getTransaction().begin();
		if(foundBooking.isVisible() == true){
			foundBooking.setVisible(false);
		}
		em.getTransaction().commit();
		
		return true;
	}
	
	public List<Booking> findAfterCurrentDate(int userId){
		EntityManager em = connection.getInstance().getEntityManager();		
		TypedQuery<Booking> query = em.createNamedQuery("booking.FindActiveBookings",Booking.class);
		query.setParameter("id", userId);
		List<Booking> bookingList = query.getResultList();
		
		return bookingList;
	}
	
	public List<Booking> findAllUserBooking(int userId){
		EntityManager em = connection.getInstance().getEntityManager();		
		TypedQuery<Booking> query = em.createNamedQuery("booking.FindUserBookings",Booking.class);
		query.setParameter("id", userId);
		List<Booking> bookingList = query.getResultList();
		
		return bookingList;
	}}
