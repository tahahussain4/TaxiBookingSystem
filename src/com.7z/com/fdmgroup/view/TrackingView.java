package com.fdmgroup.view;

import java.util.List;

import com.fdmgroup.controller.TrackingController;
import com.fdmgroup.model.Booking;
import com.fdmgroup.util.ScannerSupport;

public class TrackingView {

	TrackingController trackingController = new TrackingController();
	public void displayOption(){
		System.out.println("Please select one of the options below:");
		System.out.println("1) Display all bookings\n 2) Display booking \n3) Exit");
		String option = scanner.nextLine();
		
		switch (option) {
		case "1":
				displayAllUserBookings();
			break;
		case "2":
				displayOneBooking();
			break;
		case "3":
				System.exit(0);
		default:
			System.out.println("Invalid Option......");
			displayOptions();
			break;
		}
	}
	
	public void displayAllUserBookings(){
		List<Booking> bookingList = trackingController.getAllUserBookings();
		for(Booking booking : bookingList){
			System.out.println(booking.toString());
		}
	}
	
	public void displayActiveBookings(){
		List<Booking> bookingList = trackingController.getAllActiveBookings();
		for(Booking booking : bookingList){
			System.out.println(booking.toString());
		}
	}
	
	public void displayOneBooking(){
		System.out.println("Please specify the boooking id that you want");
		int bookingId = ScannerSupport.getInt();
		Booking booking = trackingController.getBooking(bookingId);
		System.out.println(booking.toString());
		
	}
}
