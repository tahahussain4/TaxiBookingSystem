package com.fdmgroup.view;

import java.util.Scanner;

import com.fdmgroup.controller.CarManagementController;
import com.fdmgroup.controller.FavouriteController;
import com.fdmgroup.util.ScannerSupport;

public class FavouriteView {
	Scanner scanner = new Scanner(System.in);
	FavouriteController favouriteController = new FavouriteController();

	public void displayOption(){
		System.out.println("Please Select an option");
		System.out.println("1) Add a newcar" + "\n" + "2) Delete Car \n 3) Back to main menu");
		String option = scanner.nextLine();
		
		switch(option){
			case "1":
				displayAllFavourites();
				break;
			case "2":
				displayFavourtieABooking();
				break;
			case "3":
				displayDeleteFavourite();
				break;
			default:
				System.out.println("invalid option");
				displayOption();
		}
	}
	
	public void displayFavourtieABooking(){
		System.out.println("Here are all the bookings");
		favouriteController.getAllUserFavourites();
	}
	
	public void displayAllFavourites(){
		
	}
	
	public void displayDeleteFavourite(){
		
		displayAllFavourites();
		System.out.println("enter the booking id that you want to get rid of");
		int bookingId = ScannerSupport.getInt();
		favouriteController.deleteFavourite(bookingId);
	}
}
