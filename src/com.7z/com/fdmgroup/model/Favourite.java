package com.fdmgroup.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

@Entity
@Table(name = "FAVOURITES")
@NamedQueries({
	@NamedQuery (name = "favourite.FindAll", query = "SELECT f FROM Favourite f ")
	@NamedQuery (name = "favourite.FindAllUser", query = "SELECT f FROM Favourite f Join f.booking b Join b.user u Where u.id = :id  ")
})
public class Favourite {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int favouriteId;
	
	@Column(name = "booking")
	private Booking booking;
	
	public Favourite(int booking) {
		super();
		Booking = booking;
	}
	
	/**
	 * @return the booking
	 */
	public int getBooking() {
		return Booking;
	}
	/**
	 * @param booking the booking to set
	 */
	public void setBooking(int booking) {
		Booking = booking;
	}
	public int getFavouriteId() {
		return favouriteId;
	}
	public void setFavouriteId(int favouriteId) {
		this.favouriteId = favouriteId;
	}	
}
