package com.fdmgroup.model;

public interface IStorable {
}
