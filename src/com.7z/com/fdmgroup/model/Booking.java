package com.fdmgroup.model;

import java.lang.annotation.Repeatable;
import java.time.LocalDateTime;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "BOOKINGS")
@NamedQueries({
	@NamedQuery (name = "booking.FindAll", query = "SELECT b FROM Booking b"),
	@NamedQuery (name = "booking.FindActiveBookings", query = "SELECT b FROM Booking b Join b.users where dateTime > CURRENT_TIMESTAMP AND u.id = :id"),
	@NamedQuery (name = "booking.FindUserBookings", query = "SELECT b FROM Booking b Join b.users u Where u.id = :id  ")
})
public class Booking implements IStorable{
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int bookingId; 
	
	@ManyToOne(fetch = FetchType.LAZY, cascade = {CascadeType.PERSIST})
	private User user;
	
	@ManyToOne(fetch = FetchType.LAZY, cascade = {CascadeType.PERSIST})
	private Car car;
	
	@Column(name = "dateTime")
	private LocalDateTime dateTime;
	
	@Column(name = "pickUpLocation")
	private String pickUpLocation;
	
	@Column(name = "destination")
	private String destination;
	
	@Column(name = "carPool Option")
	private Boolean carPool;
	
	@Column(name = "visibility")
	private boolean visible;
	

	public Booking(int bookingId, User user, Car car, LocalDateTime dateTime, String pickUpLocation, String destination,
			boolean carPool) {
		super();
		this.bookingId = bookingId;
		this.user = user;
		this.car = car;
		this.dateTime = dateTime;
		this.pickUpLocation = pickUpLocation;
		this.destination = destination;
		this.carPool = carPool;
	}


	public Booking(User user, Car car, LocalDateTime dateTime, String pickUpLocation, String destination,
			Boolean carPool) {
		super();
		this.user = user;
		this.car = car;
		this.dateTime = dateTime;
		this.pickUpLocation = pickUpLocation;
		this.destination = destination;
		this.carPool = carPool;
	}

	public Booking(int bookingId) {
		super();
		this.bookingId = bookingId;
	}

	/**
	 * @return the bookingId
	 */
	public int getBookingId() {
		return bookingId;
	}


	/**
	 * @param bookingId the bookingId to set
	 */
	public void setBookingId(int bookingId) {
		this.bookingId = bookingId;
	}


	/**
	 * @return the user
	 */
	public User getUser() {
		return user;
	}


	/**
	 * @param user the user to set
	 */
	public void setUser(User user) {
		this.user = user;
	}


	/**
	 * @return the car
	 */
	public Car getCar() {
		return car;
	}


	/**
	 * @param car the car to set
	 */
	public void setCar(Car car) {
		this.car = car;
	}


	/**
	 * @return the dateTime
	 */
	public LocalDateTime getDateTime() {
		return dateTime;
	}


	/**
	 * @param dateTime the dateTime to set
	 */
	public void setDateTime(LocalDateTime dateTime) {
		this.dateTime = dateTime;
	}


	/**
	 * @return the pickUpLocation
	 */
	public String getPickUpLocation() {
		return pickUpLocation;
	}


	/**
	 * @param pickUpLocation the pickUpLocation to set
	 */
	public void setPickUpLocation(String pickUpLocation) {
		this.pickUpLocation = pickUpLocation;
	}


	/**
	 * @return the destination
	 */
	public String getDestination() {
		return destination;
	}


	/**
	 * @param destination the destination to set
	 */
	public void setDestination(String destination) {
		this.destination = destination;
	}


	/**
	 * @return the carPool
	 */
	public Boolean isCarPool() {
		return carPool;
	}


	/**
	 * @param carPool the carPool to set
	 */
	public void setCarPool(Boolean carPool) {
		this.carPool = carPool;
	}


	/**
	 * @return the visible
	 */
	public boolean isVisible() {
		return visible;
	}


	/**
	 * @param visible the visible to set
	 */
	public void setVisible(boolean visible) {
		this.visible = visible;
	}


	public Booking() {
		super();
	}
	
	
}
