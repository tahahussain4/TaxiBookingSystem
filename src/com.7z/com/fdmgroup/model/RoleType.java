package com.fdmgroup.model;

public enum RoleType {
	customer,admin
}
