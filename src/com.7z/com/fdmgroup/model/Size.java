package com.fdmgroup.model;

public enum Size {
	SMALL,MEDIUM,LARGE
}
