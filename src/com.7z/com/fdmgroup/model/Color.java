package com.fdmgroup.model;

public enum Color {
	WHITE,BLACK,GREY,RED,BLUE,YELLOW,GREEN,PURPLE,EXOTIC
}
